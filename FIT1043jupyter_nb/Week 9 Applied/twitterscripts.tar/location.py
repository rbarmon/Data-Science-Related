#!/usr/bin/python

import csv
import re
import sys
import json
import string

#   got this from a webpage somewhere ... 
from math import radians, cos, sin, asin, sqrt
def haversine(lon1, lat1, lon2, lat2):
    """
    Calculate the great circle distance between two points 
    on the earth (specified in decimal degrees)
    """
    # convert decimal degrees to radians 
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])
    # haversine formula 
    dlon = lon2 - lon1 
    dlat = lat2 - lat1 
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a)) 
    km = 6367 * c
    return km

reader = csv.reader(sys.stdin, delimiter='\t')
header = next(reader)
# print 'Header = ',', '.join(header)
for row in reader:
    #print "===================================="
    #print '\n'.join(row)
    #print 'LENGTH: ' , len(row)
    #  skip headers and bad lines
    if len(row)<40 or ( row[0] == header[0] and row[1] == header[1] ):
        continue
    if not re.search("VAR1 = undef",row[11]):
        #  repair, convert from unknown format to JSON format
        jloc = re.sub("\$VAR1 = ","",row[11])
        jloc = string.replace(jloc,"'",'"')
        jloc = string.replace(jloc,"=>",":")
        jloc = string.replace(jloc,"};","}")
        #   discovered sometimes not left with a structured object
        if not re.match("^\s*{", jloc):
            continue
        # print header[11],' = ',jloc
        loc = json.loads(jloc)
        # print 'LOCATION: ' , float(loc['coordinates'][0]), float(loc['coordinates'][1])

        #  compute distance, noting two different kinds of locations
        distkm = 1000000
        melbourne = [144.963,-37.8136]
        if loc.has_key('type') and loc['type'] == 'Point':
            distkm = haversine(float(loc['coordinates'][0]), float(loc['coordinates'][1]), melbourne[0], melbourne[1])
        if loc.has_key('bounding_box'):
            #  just grab a random corner
            distkm = haversine(float(loc['bounding_box']['coordinates'][0][0][0]), float(loc['bounding_box']['coordinates'][0][0][1]), melbourne[0], melbourne[1])
        # print 'DISTANCE: ', distkm, 'km'

        if distkm<4000:
            print row[0],'\t',row[2],'\t', distkm, '\t', row[16],'\t', row[17], '\t', row[44]
            #print 'DISTANCE: ', distkm, 'km'
            #for i in [0,2,11,12,16,17]:
            #    print header[i],' = ',row[i]
