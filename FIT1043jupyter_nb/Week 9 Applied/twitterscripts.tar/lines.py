#!/usr/bin/python

import csv
import sys

#  set up the CSV reader in Python to read from STDIN
reader = csv.reader(sys.stdin, delimiter='\t')
#  first line is the header, store in case
header = next(reader)
# print 'Header = ',', '.join(header)
for row in reader:
    #  check the hash to see if its a matching city
    if len(row)<40:
        print row
