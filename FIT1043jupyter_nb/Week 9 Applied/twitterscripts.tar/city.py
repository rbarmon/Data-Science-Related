#!/usr/bin/python

import csv
import sys

#  create a hash table of Australian cities, using those found in
#  the TMZ field
city = {}
city['Adelaide'] = True;
city['Brisbane'] = True;
city['Canberra'] = True;
city['Darwin'] = True;
city['Hobart'] = True;
city['Melbourne'] = True;
city['Perth'] = True;
city['Sydney'] = True;

#  set up the CSV reader in Python to read from STDIN
reader = csv.reader(sys.stdin, delimiter='\t')
#  first line is the header, store in case
header = next(reader)
# print 'Header = ',', '.join(header)
for row in reader:
    #  check the hash to see if its a matching city
    if city.get(row[44]):
        print row[0],'\t',row[2], '\t', row[16],'\t', row[17], '\t', row[44]
